declare module 'statorgfc' {
  export let store: {
    get(key: string): any
  }
}